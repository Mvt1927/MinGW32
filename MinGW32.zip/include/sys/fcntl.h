/*
 * This file is part of the Mingw32 package.
 *
 * This fcntl.h maps to the root fcntl.h
 */

#include <fcntl.h>
